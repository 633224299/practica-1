# Laboratorio de Seguridad Perimetral con FortiGate

📹 **Video demostrativo:** [enlace pendiente — colócalo aquí al principio]

## Propósito

Implementación de una arquitectura de seguridad perimetral con FortiGate (configurado y demostrado íntegramente por GUI), un switch con segmentación VLAN, dos servidores (Web/DB) en una subred /28, y una red de usuarios en VLAN 10 (/25) con DHCP.

## Estructura del repositorio

```
/docs
  informe.docx / informe.pdf   → Documentación profesional completa (propósito, diagramas, imágenes, configuración)
/scripts
  sqli_test.py                 → Script de prueba de payloads SQL Injection contra el Web-Server
/running-configs
  fortigate-running-config.txt → (pendiente) show full-configuration del FortiGate
  switch-running-config.txt    → (pendiente) configuración del switch
```

## Estado actual

- ✅ Topología completa desplegada y verificada en GNS3 (FortiGate, switch con VLAN 1/10, Web-Server, DB-Server, red de usuarios)
- ✅ Direccionamiento IP y segmentación por VLAN funcionando (conectividad ICMP verificada)
- ⏳ Configuración por GUI de rutas, NAT, políticas, DPI, SQL Injection + cuarentena, restricción Web→DB, filtrado de .exe y rate limiting — pendiente de completar (ver informe para el detalle del inconveniente técnico y el estado exacto)

## Cómo usar el script de prueba

```bash
pip install requests --break-system-packages
python3 scripts/sqli_test.py --target https://192.168.10.2
```

Revisar los resultados en la GUI del FortiGate: **Log & Report > Security Events**.
