#!/usr/bin/env python3
"""
sqli_test.py

Script de prueba para validar la regla de detección/bloqueo de SQL Injection
del FortiGate hacia el WEB-Server del laboratorio.

Uso:
    python3 sqli_test.py --target https://192.168.10.2

Requiere: pip install requests --break-system-packages

Cada payload se envía como parámetro GET a la raíz del servidor. El objetivo
NO es explotar una vulnerabilidad real del Web-Server (puede no tener ninguna
aplicación vulnerable detrás), sino generar tráfico que coincida con las
firmas de SQL Injection del motor DPI/IPS del FortiGate, para así:
  1) Confirmar que el FortiGate bloquea la petición (timeout / conexión
     rechazada / página de bloqueo del FortiGate en vez de respuesta normal).
  2) Confirmar en los logs del FortiGate (Log & Report > Security Events)
     que la firma fue detectada y el atacante quedó en cuarentena.
"""

import argparse
import sys
import time

try:
    import requests
except ImportError:
    print("Falta la librería 'requests'. Instala con: pip install requests --break-system-packages")
    sys.exit(1)

PAYLOADS = [
    "' OR '1'='1",
    "' OR 1=1 --",
    "admin'--",
    "' UNION SELECT null, null, null --",
    "1' AND '1'='1",
    "'; DROP TABLE users; --",
    "' OR 'a'='a",
    "1 OR 1=1",
    "' UNION SELECT username, password FROM users --",
    "%27%20OR%201%3D1--",  # variante URL-encoded
]


def send_payload(target, payload, timeout=5):
    params = {"id": payload, "search": payload}
    try:
        resp = requests.get(target, params=params, timeout=timeout, verify=False)
        return f"HTTP {resp.status_code} ({len(resp.content)} bytes)"
    except requests.exceptions.Timeout:
        return "TIMEOUT (posible bloqueo/cuarentena del FortiGate)"
    except requests.exceptions.ConnectionError as e:
        return f"CONNECTION ERROR (posible bloqueo/cuarentena del FortiGate): {e}"


def main():
    parser = argparse.ArgumentParser(description="Prueba de payloads SQL Injection contra el Web-Server")
    parser.add_argument("--target", required=True, help="URL del Web-Server, ej. https://192.168.10.2")
    parser.add_argument("--delay", type=float, default=1.0, help="Segundos de espera entre payloads")
    args = parser.parse_args()

    print(f"Objetivo: {args.target}")
    print(f"Total de payloads: {len(PAYLOADS)}\n")

    for i, payload in enumerate(PAYLOADS, start=1):
        print(f"[{i}/{len(PAYLOADS)}] Payload: {payload}")
        result = send_payload(args.target, payload)
        print(f"      Resultado: {result}\n")
        time.sleep(args.delay)

    print("Prueba finalizada. Revisa en la GUI del FortiGate:")
    print("  Log & Report > Security Events (o Forward Traffic) para confirmar")
    print("  las detecciones, el bloqueo y la cuarentena del origen de estas peticiones.")


if __name__ == "__main__":
    main()
